
const AWS = require("aws-sdk");
const dynamo = new AWS.DynamoDB.DocumentClient({ region: "us-east-1" });

exports.handler = async (event) => {
  console.log("Event:", JSON.stringify(event));

  try {
    // table for all reviews
    const result = await dynamo
      .scan({
        TableName: "ReviewAnalysis", 
      })
      .promise();

    //Sort reviews by timestamp (newest first)
    const items = result.Items.sort(
      (a, b) => new Date(b.timestamp) - new Date(a.timestamp)
    );

    //Success response with CORS headers
    return {
      statusCode: 200,
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Methods": "GET,POST,OPTIONS",
        "Access-Control-Allow-Headers": "Content-Type",
        "Content-Type": "application/json",
      },
      body: JSON.stringify(items),
    };
  } catch (err) {
    console.error("Error fetching reviews:", err);

    //Error response with CORS headers
    return {
      statusCode: 500,
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Methods": "GET,POST,OPTIONS",
        "Access-Control-Allow-Headers": "Content-Type",
      },
      body: JSON.stringify({
        message: "Failed to fetch reviews",
        error: err.message,
      }),
    };
  }
};

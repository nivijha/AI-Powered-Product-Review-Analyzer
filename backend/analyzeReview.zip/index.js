const AWS = require("aws-sdk");
const comprehend = new AWS.Comprehend({ region: "us-east-1" });
const dynamo = new AWS.DynamoDB.DocumentClient({ region: "us-east-1" });
const { v4: uuidv4 } = require("uuid");

exports.handler = async (event) => {
  console.log("Incoming event:", JSON.stringify(event));

  try {
    // parse JSON body (only for POST)
    const body = event.body ? JSON.parse(event.body) : {};
    const { reviewText } = body;

    if (!reviewText) {
      return {
        statusCode: 400,
        headers: {
          "Access-Control-Allow-Origin": "*",
          "Access-Control-Allow-Methods": "GET,POST,OPTIONS",
          "Access-Control-Allow-Headers": "Content-Type",
        },
        body: JSON.stringify({ message: "Missing reviewText" }),
      };
    }

    //Amazon Comprehend to analyze sentiment
    const sentimentData = await comprehend
      .detectSentiment({
        Text: reviewText,
        LanguageCode: "en",
      })
      .promise();

    const sentiment = sentimentData.Sentiment;
    const scores = sentimentData.SentimentScore;

    //Store result in DynamoDB
    const item = {
      id: uuidv4(),
      reviewText,
      sentiment,
      score: scores[sentiment],
      allScores: scores,
      timestamp: new Date().toISOString(),
    };

    await dynamo
      .put({
        TableName: "ReviewAnalysis",
        Item: item,
      })
      .promise();

    // success
    return {
      statusCode: 200,
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Methods": "GET,POST,OPTIONS",
        "Access-Control-Allow-Headers": "Content-Type",
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        Sentiment: sentiment,
        Score: scores[sentiment],
        AllScores: scores,
      }),
    };
  } catch (error) {
    console.error("Error:", error);

    return {
      statusCode: 500,
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Methods": "GET,POST,OPTIONS",
        "Access-Control-Allow-Headers": "Content-Type",
      },
      body: JSON.stringify({
        message: "Error analyzing sentiment",
        error: error.message,
      }),
    };
  }
};
